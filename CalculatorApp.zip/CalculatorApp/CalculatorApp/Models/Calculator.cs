﻿namespace CalculatorApp.Models
{
    public enum CurrentState
    {
        FirstNumber,
        SecondNumber
    }

    public class Calculator
    {
        public double FirstNumber { get; set; }
        public double SecondNumber { get; set; }
        public string MathOperator { get; set; } = "";
        public string Result { get; set; } = "0";
        public string Equation { get; set; } = "";
        public CurrentState CurrentState { get; set; } = CurrentState.FirstNumber;

        public Calculator()
        {
            Reset();
        }

        public void Reset()
        {
            FirstNumber = 0;
            SecondNumber = 0;
            MathOperator = "";
            Result = "0";
            Equation = "";
            CurrentState = CurrentState.FirstNumber;
        }

        public void Clear()
        {
            Result = "0";
        }

        public double PerformCalculation()
        {
            double result = 0;

            switch (MathOperator)
            {
                case "+":
                    result = MathUtil.Add(FirstNumber, SecondNumber);
                    break;
                case "-":
                    result = MathUtil.Subtract(FirstNumber, SecondNumber);
                    break;
                case "×":
                    result = MathUtil.Multiply(FirstNumber, SecondNumber);
                    break;
                case "÷":
                    result = MathUtil.Divide(FirstNumber, SecondNumber);
                    break;
                case "%":
                    result = MathUtil.Percentage(FirstNumber, SecondNumber);
                    break;
                default:
                    result = SecondNumber;
                    break;
            }

            return result;
        }
    }
}