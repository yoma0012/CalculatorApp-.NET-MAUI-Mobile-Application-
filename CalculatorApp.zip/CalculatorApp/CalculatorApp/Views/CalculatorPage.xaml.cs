using CalculatorApp.Models;

namespace CalculatorApp.Views;

public partial class CalculatorPage : ContentPage
{
    // Global Variables (Required)
    private double firstNumber = 0;
    private double secondNumber = 0;
    private string mathOperator = "";
    private CurrentState currentState = CurrentState.FirstNumber;

    // Calculator instance for state management
    private Calculator calculator;
    private bool isNewNumber = true;

    public CalculatorPage()
    {
        InitializeComponent();
        calculator = new Calculator();
    }

    // Number button click handler
    private void OnNumberClicked(object sender, EventArgs e)
    {
        var button = sender as Button;
        var number = button?.Text;

        if (isNewNumber)
        {
            calculator.Result = number == "0" ? "0" : number;
            isNewNumber = false;
        }
        else
        {
            if (calculator.Result == "0")
                calculator.Result = number;
            else
                calculator.Result += number;
        }

        numbersLabel.Text = calculator.Result;
        UpdateCurrentNumber();
    }

    // Operator button click handler
    private void OnOperatorClicked(object sender, EventArgs e)
    {
        var button = sender as Button;
        var op = button?.Text;

        if (currentState == CurrentState.FirstNumber)
        {
            firstNumber = double.Parse(calculator.Result);
            calculator.FirstNumber = firstNumber;
            currentState = CurrentState.SecondNumber;
        }
        else if (currentState == CurrentState.SecondNumber && !isNewNumber)
        {
            secondNumber = double.Parse(calculator.Result);
            calculator.SecondNumber = secondNumber;
            calculator.MathOperator = mathOperator;

            try
            {
                var result = calculator.PerformCalculation();
                calculator.Result = result.ToString();
                numbersLabel.Text = calculator.Result;
                firstNumber = result;
                calculator.FirstNumber = firstNumber;
            }
            catch (DivideByZeroException)
            {
                calculator.Result = "Error";
                numbersLabel.Text = calculator.Result;
                ResetCalculator();
                return;
            }
        }

        mathOperator = op;
        calculator.MathOperator = mathOperator;
        isNewNumber = true;

        UpdateEquation();
    }

    // Equals button click handler
    private void OnEqualsClicked(object sender, EventArgs e)
    {
        if (currentState == CurrentState.SecondNumber && !isNewNumber)
        {
            secondNumber = double.Parse(calculator.Result);
            calculator.SecondNumber = secondNumber;
            calculator.MathOperator = mathOperator;

            try
            {
                var result = calculator.PerformCalculation();
                calculator.Result = result.ToString();

                // Update equation to show complete calculation
                calculator.Equation = $"{firstNumber} {mathOperator} {secondNumber} =";
                equationLabel.Text = calculator.Equation;
                numbersLabel.Text = calculator.Result;

                ResetCalculator();
            }
            catch (DivideByZeroException)
            {
                calculator.Result = "Error";
                numbersLabel.Text = calculator.Result;
                ResetCalculator();
            }
        }
    }

    // Clear button click handler
    private void OnClearClicked(object sender, EventArgs e)
    {
        ResetCalculator();
        calculator.Reset();
        numbersLabel.Text = "0";
        equationLabel.Text = "";
    }

    // Clear Entry button click handler
    private void OnClearEntryClicked(object sender, EventArgs e)
    {
        calculator.Clear();
        numbersLabel.Text = "0";
        isNewNumber = true;
    }

    // Decimal point button click handler
    private void OnDecimalClicked(object sender, EventArgs e)
    {
        if (isNewNumber)
        {
            calculator.Result = "0.";
            isNewNumber = false;
        }
        else if (!calculator.Result.Contains("."))
        {
            calculator.Result += ".";
        }

        numbersLabel.Text = calculator.Result;
        UpdateCurrentNumber();
    }

    // Negate button click handler
    private void OnNegateClicked(object sender, EventArgs e)
    {
        if (calculator.Result != "0")
        {
            if (calculator.Result.StartsWith("-"))
                calculator.Result = calculator.Result.Substring(1);
            else
                calculator.Result = "-" + calculator.Result;

            numbersLabel.Text = calculator.Result;
            UpdateCurrentNumber();
        }
    }

    // Percentage button click handler
    private void OnPercentageClicked(object sender, EventArgs e)
    {
        var currentValue = double.Parse(calculator.Result);
        var result = currentValue / 100;
        calculator.Result = result.ToString();
        numbersLabel.Text = calculator.Result;
        UpdateCurrentNumber();
        isNewNumber = true;
    }

    // Helper method to update current number based on state
    private void UpdateCurrentNumber()
    {
        if (currentState == CurrentState.FirstNumber)
        {
            if (double.TryParse(calculator.Result, out double value))
            {
                firstNumber = value;
                calculator.FirstNumber = firstNumber;
            }
        }
        else
        {
            if (double.TryParse(calculator.Result, out double value))
            {
                secondNumber = value;
                calculator.SecondNumber = secondNumber;
            }
        }
    }

    // Helper method to update equation display
    private void UpdateEquation()
    {
        if (currentState == CurrentState.SecondNumber)
        {
            calculator.Equation = $"{firstNumber} {mathOperator}";
            equationLabel.Text = calculator.Equation;
        }
    }

    // Helper method to reset calculator state
    private void ResetCalculator()
    {
        firstNumber = 0;
        secondNumber = 0;
        mathOperator = "";
        currentState = CurrentState.FirstNumber;
        isNewNumber = true;
    }
}